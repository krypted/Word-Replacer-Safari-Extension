//
//  Constants.swift
//  Word Replacer
//
//  Created by admin on 05.03.2021.
//  Copyright © 2021 Charles. All rights reserved.
//

let BundleIDForExtension = "com.charles.word-replacer.extension"
let WR_ORIGINAL = "WR_ORIGINAL"
let WR_NEW = "WR_NEW"
let WR_LOADED = "WR_LOADED"
let WR_REPLACE = "WR_REPLACE"
let WR_ON = "WR_ON"
