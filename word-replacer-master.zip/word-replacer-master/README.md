# Word Replacer Safari App Extension

## Environment
- Xcode 9.4+
- Mac OS X 10.15+
- Safari 11.1+

## Instruction to build/run App and Safari App Extension in Xcode
After you install Xcode in your mac, follow the steps below:

1. Open `Word Replacer.xcodeproj` in Xcode.

2. Click Product/Run once you choose the Scheme("Word Replacer").

Then Word Replacer app will be shown.

3. To see Safari App Extension, follow the instructions that you see in the screen of the app.
